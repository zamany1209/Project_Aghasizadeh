(function () {
    'use strict';
    // cssVars({
    //     onlyLegacy: false,
    //     include: 'link[href="assets/css/main.css"],style',
    //     onComplete: function (cssText, styleNode) {}
    // });
}());